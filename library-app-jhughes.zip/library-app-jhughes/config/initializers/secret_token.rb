# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
LibraryApp::Application.config.secret_token = '5c0e95b4360f4d6cd741fd2a373c28de0b738459917fe9ac981a7924f35c98634430fd817c5c1f70ad06e567aee54e0eb5cac37ca3789e81c0c6c975b11fa576'
