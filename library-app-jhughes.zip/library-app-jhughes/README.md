## Introduction

*   The purpose of this application is to showcase your technical, analytical, written and verbal skills.
*   Once your system has been configured, please spend an hour reviewing, enhancing, pseudo-coding, coding and/or commenting on the application. Feel free to spend more than an hour, but it is not required.
*   Your code changes, enhancements and/or comments will be used as the starting point of a technical discussion with the team. It will be a unstructured format that will focus on the entire stack.

## Application Overview:

This application displays the relationship between a customer and a library. It includes 8 models:

1.  User
2.  Librarian
3.  Customer
4.  Library
5.  Book
6.	AudioBook
7.	PhysicalBook
8.	CustomerBook

The db/seeds.rb file is preloaded with test data. Please use this when you setup your DB.

## Suggested Tasks:

*		Review the code for best practices, efficiencies or logic flaws.
*		Review the test suite for any gaps.
*		Build a new report that lists customers with a count of different types of books.
*		Build an import process to retrieve new books from a file.
*		Build a process to review new books and deliver then to the customer.

## Extra Credit:

*		Review and/or update the code for any potenial security issues.
*		Review and/or update the code for any performance related changes.
*		Enhance the usability and/or design.

## Project Setup

Clone this repo locally, and from the top-level directory run:

`bundle install`

`bundle exec rake db:setup`

To make sure it's all working,

`rails s`

You should see this same information.

## Project Review

Please commit any updates and/or comments to the repo. Add any additional comments, notes and/or instructions in the README under the "Enhancements" section. Also note if the db/seeds.rb file has been updated. The development team will review your submission and be ready for the technical portion of your interview.

## Enhancements

The biggest problem I see that needs addressing is there is no sign-in logic or sessions logic to regulate access to different areas and features within the app. So I implemented the Devise gem, a well-known method for user authentication. Doing this would allow for different accounts to be set up (librarian "admins", customers) and different privileges assigned. If you go to http://localhost:3000/users/sign_in you will see there is now a functioning sign-in prompt.

Other comments on the application:

UI missing a way to perform CRUD actions on books. 

UI missing a way to perform CRUD actions on customers. 

There are no "private" methods in any of the controllers. 

Clicking "Customer View" in UI always takes you to the same URL ("http://localhost:3000/users/2?view=customer").

database.yml contains remarks that need to be fixed for security purposes. The current remarks aren't necessary, don't appear to belong there, or prevent app's database from being created or accessed:
	username: postgres
	password:
	host: 127.0.0.1

The app should have a sessions controller and user password validations to regulate permissions between librarian privileges vs. customer privileges. UI missing login prompts to differentiate access between customers and librarians. sThis can be addressed by adding the Devise gem, as discussed above. 

Polymorphic inheritance (mixins?) for different types of models (AudioBook, PhysicalBook, CustomerBook). 

