class PhysicalBook < Book
  
end