class Librarian < User

end