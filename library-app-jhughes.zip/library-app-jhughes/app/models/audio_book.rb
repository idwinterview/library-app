class AudioBook < Book
  
end